import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Home, Leaf, Building, Settings, LogOut } from 'lucide-react'
import { useAuthStore } from '../stores/store'

export default function Sidebar() {
  const location = useLocation()
  const logout = useAuthStore((state) => state.logout)

  const navigation = [
    { name: 'Dashboard', href: '/', icon: Home },
    { name: 'Emissions', href: '/emissions', icon: Leaf },
    { name: 'Campus', href: '/campus', icon: Building },
    { name: 'Settings', href: '/settings', icon: Settings },
  ]

  return (
    <aside className="w-64 bg-gradient-to-b from-green-700 to-green-800 text-white shadow-lg">
      <div className="p-6">
        <div className="flex items-center gap-2">
          <Leaf className="w-8 h-8" />
          <h1 className="text-xl font-bold">EcoCampus</h1>
        </div>
      </div>

      <nav className="mt-8 space-y-2 px-4">
        {navigation.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname === item.href
          return (
            <Link
              key={item.name}
              to={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-white bg-opacity-20'
                  : 'hover:bg-white hover:bg-opacity-10'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.name}</span>
            </Link>
          )
        })}
      </nav>

      <div className="absolute bottom-0 left-0 right-0 border-t border-green-600 p-4">
        <button
          onClick={logout}
          className="flex items-center gap-2 w-full px-4 py-2 text-sm hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  )
}
